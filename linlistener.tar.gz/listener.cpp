#include <iostream>
#include <vector>
#include <cstdint>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/ethernet.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <arpa/inet.h>

int main() {
    // L2 сокет зчитує кадри безпосередньо з мережевої карти
    int sock = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (sock < 0) {
        std::cerr << "Run with sudo!" << std::endl;
        return 1;
    }

    std::cout << "=== Linux L2 Raw Sniffer Active (Capturing ALL BOOTP/DHCP Frames) ===" << std::endl;

    std::vector<uint8_t> buf(65536);

    while (true) {
        ssize_t bytes = recv(sock, buf.data(), buf.size(), 0);
        if (bytes < 42) continue; // Ethernet (14) + IP (20) + UDP (8)

        // Ethernet
        const auto* eth = reinterpret_cast<const struct ether_header*>(buf.data());
        if (ntohs(eth->ether_type) != ETHERTYPE_IP) continue;

        // IP
        const auto* ip = reinterpret_cast<const struct iphdr*>(buf.data() + 14);
        if (ip->protocol != IPPROTO_UDP) continue;

        size_t ipLen = ip->ihl * 4;
        if (bytes < static_cast<ssize_t>(14 + ipLen + 8)) continue;

        // UDP (ігноруємо контрольні суми та валідність BOOTP-полів)
        const auto* udp = reinterpret_cast<const struct udphdr*>(buf.data() + 14 + ipLen);
        uint16_t srcPort = ntohs(udp->source);
        uint16_t dstPort = ntohs(udp->dest);

        if (srcPort == 67 || srcPort == 68 || dstPort == 67 || dstPort == 68) {
            char srcIp[INET_ADDRSTRLEN], dstIp[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &ip->saddr, srcIp, sizeof(srcIp));
            inet_ntop(AF_INET, &ip->daddr, dstIp, sizeof(dstIp));

            std::cout << "[L2 RECV] " << srcIp << ":" << srcPort 
                      << " -> " << dstIp << ":" << dstPort 
                      << " | Frame Size: " << bytes << " bytes" << std::endl;
        }
    }

    close(sock);
    return 0;
}
